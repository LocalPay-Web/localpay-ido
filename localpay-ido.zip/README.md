# LocalPay IDO
Trang web chính thức sự kiện gọi vốn token LPAY.